'use strict';
const decimal = require('./decimal');
const canonical = require('./canonical');
const { computeSaleEffect } = require('./effect');
const { applySchema } = require('./schema');
const outbox = require('./outbox');
const reconcile = require('./reconcile');
const { createEngine } = require('./engine');
const hook = require('./hook');

/** Interruptor general. Por defecto APAGADO: el POS se comporta exactamente como antes. */
function isEnabled() { return process.env.LMM_INVENTORY_SYNC_V8 === '1'; }

module.exports = { isEnabled, decimal, canonical, computeSaleEffect, applySchema, outbox, reconcile, createEngine, hook };
