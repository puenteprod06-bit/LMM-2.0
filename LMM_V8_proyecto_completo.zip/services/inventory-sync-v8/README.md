# inventory-sync-v8

Implementación inicial (cliente) del diseño `INVENTORY_SYNC_PHASE_2B5_1_ARCHITECTURE_DESIGN_V8.md`.
**Apagada por defecto**: solo actúa con `LMM_INVENTORY_SYNC_V8=1`.

## Qué hay
| Archivo | Rol |
|---|---|
| `decimal.js` | cantidades en milésimas enteras y strings decimales canónicos |
| `canonical.js` | JSON canónico + SHA-256 del intent (idéntico al servidor) |
| `effect.js` | regla de venta (`computeSaleEffect`) — saldo negativo nunca es disponible |
| `schema.js` | esquema SQLite aditivo (lo llama `db.js`) |
| `outbox.js` | cola local: reclamo atómico, lease, backoff, partición, dead_letter/conflict |
| `reconcile.js` | stock confirmado/provisional, `applyAuthoritativeResultTx`, cursor de eventos, snapshot |
| `engine.js` | motor `drain` / `pollEvents` con `rpc` inyectable (sin red en transacciones) |
| `hook.js` | puente con `routes/orders.js` (creación de pedido → operación `sale`) |

Esquema remoto: `supabase/migrations/20261123000000_lmm_inventory_sync_v8.sql` (**no ejecutado**; solo validada su sintaxis). Revisión V8.1: incluye las correcciones de la auditoría externa.

## Qué falta antes de encender el interruptor
1. Cliente `rpc` real sobre `@supabase/supabase-js` (`lmm_apply_operation`, `lmm_get_events`, `lmm_get_snapshot`) y su arranque en `server.js`/`sync-engine.js`.
2. Encolar `modify` (fusión de pedidos), `cancel`, `reopen`, devoluciones y ajustes (hoy solo se encola la venta de un pedido nuevo).
3. Ejecutar y aprobar las funciones remotas (ya escritas en la migración: snapshot, enrolamiento, revocación, purga, migración de pedidos abiertos).
4. Ejecutar la migración en un Supabase **aislado** y aprobar la matriz de pruebas del diseño (secciones 19–20).
5. Migración de datos (sección 17 del diseño): saldo inicial decidido por el propietario, cuarentena de `sync_queue` de inventario.

## Pruebas
`npx jest tests/inventory-sync-v8.test.js` (o `node scripts/run-tests.js tests/inventory-sync-v8.test.js`).
Usan `better-sqlite3` si está disponible y, si no, el SQLite embebido de Node.
